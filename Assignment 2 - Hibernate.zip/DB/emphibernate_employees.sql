-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: emphibernate
-- ------------------------------------------------------
-- Server version	8.0.25

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employees` (
  `id` int NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `age` int DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `salary` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (4,'81 Fallview Place',45,'Val','Matthis',12214),(5,'574 Roth Junction',25,'Rollins','Gleader',15077),(6,'4 Stoughton Parkway',15,'Grete','Allon',16957),(7,'0 Kennedy Street',29,'Giacopo','Repper',4528),(8,'971 Sommers Circle',81,'Saunderson','Segge',16500),(9,'18684 Goodland Plaza',46,'Edi','Harston',10713),(10,'90002 Dryden Junction',71,'Kim','Alway',11361),(11,'156 Sachtjen Drive',6,'Amabelle','Fraser',7209),(12,'407 Ramsey Pass',33,'Josepha','Emloch',4173),(13,'79503 Lighthouse Bay Lane',3,'Janos','Warry',18751),(14,'1 Wayridge Park',60,'Reider','Geroldini',4806),(15,'176 Graedel Hill',60,'Merci','Airs',15925),(16,'85466 Iowa Junction',27,'Wye','Moncreiffe',17682),(17,'3280 Leroy Alley',40,'Nissa','Crumb',3707),(18,'727 Utah Way',10,'Delinda','Griston',1135),(19,'64532 Butternut Park',1,'Nickolas','Trimble',17751),(20,'06795 Porter Crossing',97,'Urbanus','Longworthy',19923),(21,'595 Springview Street',100,'Collen','Hicks',15920),(23,'51011 Forster Plaza',29,'Gray','Sirman',7008),(24,'6696 Bashford Center',29,'Poppy','Costard',12454),(25,'4 Stone Corner Junction',100,'Rois','Cavilla',18910),(26,'64073 Vera Park',91,'Walker','Heintz',17236),(27,'86 Harbort Center',96,'Amos','Motten',11233),(28,'5 Maywood Terrace',21,'Cirstoforo','Danilovich',15931),(29,'81 Heath Court',18,'Wendi','Ackers',9033),(30,'39431 Oriole Trail',69,'Dominique','Buffin',14954),(31,'53 Burrows Lane',36,'Quintana','Feeney',17230),(32,'229 Paget Court',55,'Jeanie','Lindborg',18294),(33,'300 Red Cloud Crossing',91,'Rafaelita','Jindrich',19847),(34,'9140 Sutteridge Avenue',63,'Cori','MacKey',8856),(35,'02 Donald Plaza',61,'Perla','Murrey',7438),(36,'7506 Summerview Center',9,'Fowler','Bartolomivis',16092),(37,'535 Havey Pass',58,'Gladys','Kasperski',16395),(38,'6 Donald Lane',20,'Valry','Pierrepoint',12135),(39,'454 Northwestern Alley',71,'Claudio','Noweak',8631),(40,'520 Annamark Circle',35,'Franzen','Hebbes',17550),(41,'61832 Springs Street',66,'Joelle','Giamitti',18978),(42,'26031 Clemons Parkway',41,'Mikey','Lievesley',10916),(43,'14495 Becker Road',1,'Nedi','Burgis',11526),(44,'73 Farragut Pass',55,'Eada','Orto',8452),(45,'589 Almo Hill',100,'Vickie','Pauleau',19555),(46,'1569 Main Park',100,'Donal','Foxcroft',14319),(47,'8028 Northfield Pass',58,'Francesca','Mantz',13162),(48,'80 Northridge Hill',29,'Gerhardt','Eynon',9911),(49,'7244 Weeping Birch Parkway',36,'Calida','Kitney',7740),(50,'796 Killdeer Plaza',62,'Aundrea','Corbyn',12471),(51,'98063 Shelley Circle',41,'Allistir','Keyme',14238),(52,'715 Golf Course Crossing',71,'Kimberley','Scard',7674),(53,'15 Holy Cross Park',49,'Karil','Aidler',4329),(54,'4031 Grim Park',25,'Iain','Brinkley',19183),(55,'562 Mifflin Plaza',37,'Yanaton','Dash',5859),(56,'476 Mosinee Hill',48,'Eolanda','Vaines',4346),(57,'0 Summer Ridge Way',19,'Darnell','Rospars',10405),(58,'30897 Sherman Street',29,'Bev','Mayes',15204),(59,'68658 Russell Crossing',17,'Derby','Gras',10282),(60,'43 4th Alley',87,'Blanca','Jevons',15337),(61,'521 Becker Pass',23,'Silvain','Balharrie',1403),(62,'6664 Kedzie Pass',71,'Harlan','Ankrett',14083),(63,'3 Rutledge Trail',69,'Gabi','Fairhurst',15668),(64,'6 Esch Hill',76,'Winifield','Lisamore',11350),(65,'82550 Crownhardt Center',30,'Charin','Ubsdale',10265),(66,'3274 Nova Center',86,'Felipe','Mufford',12453),(67,'72 Norway Maple Parkway',36,'Salomon','Sherburn',15573),(68,'106 Golden Leaf Parkway',23,'Dulcinea','Kruschev',13339),(69,'44770 Oakridge Alley',15,'Diane-marie','Diack',11932),(70,'780 Gateway Park',100,'Lynne','Crookall',9726),(71,'98540 Mcbride Street',27,'Xenia','Savary',18275),(72,'01168 Green Ridge Pass',75,'Kendal','Rought',19882),(73,'31 School Center',50,'Berny','Milberry',13263),(74,'95099 Johnson Crossing',11,'Avivah','Jeaffreson',19153),(75,'7 Stoughton Center',7,'Raphaela','Monini',8091),(76,'076 Tennyson Alley',2,'Kit','Lowen',5914),(77,'3 Emmet Street',32,'Wilhelmine','Stears',2636),(78,'81374 Clemons Way',75,'Elora','Knight',9185),(79,'30 Canary Center',13,'Neilla','Verden',13559),(80,'350 Trailsway Lane',92,'Wadsworth','Goulborne',8289),(81,'72 Clarendon Drive',69,'Thornie','Bogie',6212),(82,'3 Village Center',3,'Chantalle','Whittaker',6871),(83,'99 Dottie Pass',44,'Beryle','Kollatsch',4867),(84,'499 Springview Plaza',94,'Perren','Sandever',8937),(85,'5750 Hazelcrest Hill',94,'Dar','Auchinleck',12827),(86,'23730 Redwing Park',38,'Hamilton','Knappitt',3487),(87,'078 Roth Junction',86,'Agustin','Mozzi',12777),(88,'87 Pennsylvania Avenue',35,'Leyla','Whittuck',14686),(89,'89129 Bowman Point',26,'Gayle','McNeice',18340),(90,'3 Mallard Terrace',46,'Coral','Stockhill',18514),(91,'211 Laurel Drive',84,'Aurlie','Sandiford',18506),(92,'76 Luster Junction',95,'Marga','Synke',13451),(93,'9713 Banding Pass',8,'Brent','Lindeberg',1129),(94,'7 Corry Center',82,'Maribelle','Bassett',4995),(95,'5 Cascade Alley',25,'Shanon','Cosson',3637),(96,'38 Independence Junction',43,'Lesley','Pagel',12293),(97,'09992 Hanover Pass',44,'Ashley','Olver',17732),(98,'29 Crescent Oaks Alley',2,'Zeb','Hansie',19862),(99,'62854 Dapin Drive',24,'Erastus','Cattle',11368),(100,'2807 Continental Drive',35,'Netti','Denkin',2013);
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-10-11 13:05:46
