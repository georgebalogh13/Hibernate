package com.company;

import org.hibernate.QueryException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import java.util.List;
import java.util.Scanner;

public class Main {


    public static void main(String[] args) {

        showMenu();


        Scanner scan = new Scanner(System.in);
        int optiune = Integer.parseInt(scan.nextLine());
        SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
        while (optiune!=7){

        if (optiune==1){
            System.out.println("1. Introduceti un angajat nou in baza de date.");

            System.out.println("Introduceti prenumele.");
            String prenume = scan.nextLine();
            System.out.println("Introduceti numele.");
            String nume = scan.nextLine();
            System.out.println("Introduceti adresa.");
            String adresa = scan.nextLine();
            System.out.println("Introduceti varsta.");
            Integer varsta = Integer.parseInt(scan.nextLine());
            System.out.println("Introduceti salariul.");
            Integer salariu = Integer.parseInt(scan.nextLine());

            Session session = sessionFactory.openSession();
            session.beginTransaction();
            Employee employee = new Employee();
            employee.setFirstName(prenume);
            employee.setLastName(nume);
            employee.setAddress(adresa);
            employee.setAge(varsta);
            employee.setSalary(salariu);
            session.save(employee);
            session.getTransaction().commit();
            session.close();

            System.out.println("Angajat introdus cu succes.");

        } else if (optiune==2){
            System.out.println("2. Modificati datele unui angajat pe baza ID-ului.");
            System.out.println("Introduceti ID-ul pe care doriti sa il modificati.");
            int id = Integer.parseInt(scan.nextLine());
            Session session = sessionFactory.openSession();
            session.beginTransaction();
            Employee emp = session.get(Employee.class, id);
            System.out.println(emp);
            if (emp!=null){
                System.out.println(emp);
                System.out.println("Introduceti noul prenume");
                String prenume = scan.nextLine();
                System.out.println("Introduceti noul nume");
                String nume = scan.nextLine();
                System.out.println("Intoduceti noua adresa");
                String adresa = scan.nextLine();
                System.out.println("Introduceti noua varsta");
                Integer varsta = Integer.parseInt(scan.nextLine());
                System.out.println("Introduceti noul salariu");
                Integer salariu = Integer.parseInt(scan.nextLine());

                emp.setFirstName(prenume);
                emp.setLastName(nume);
                emp.setAddress(adresa);
                emp.setAge(varsta);
                emp.setSalary(salariu);

            } else {
                System.out.println("Angajatul nu exista.");
            }

            session.getTransaction().commit();
            session.close();

        } else if (optiune==3){
            System.out.println("3. Stergeti un angajat din baza de date");
            System.out.println("Introduceti ID-ul angajatului pe care doriti sa-l stergeti.");
            int id = Integer.parseInt(scan.nextLine());
            Session session = sessionFactory.openSession();
            session.beginTransaction();
            Employee emp = session.get(Employee.class, id);
            System.out.println(emp);
            if (emp!=null){
                session.delete(emp);
                System.out.println("Angajatul a fost sters cu succes.");
            } else{
                System.out.println("Angajatul nu exista in baza de date.");
            }
            session.getTransaction().commit();
            session.close();

        } else if (optiune==4){
            System.out.println("4. Afisati toti angajatii din baza de date");
            Session session = sessionFactory.openSession();
            session.beginTransaction();
            Query query = session.createQuery("from Employee");
            List<Employee> employeeList = query.list();
            for(Employee emp:employeeList){
                System.out.println(emp);
            }
            session.getTransaction().commit();
            session.close();

        }
        else if (optiune==5){
            System.out.println("5. Afisati angajatii mai mari ca pe varsta pe care o doriti.");
            System.out.println("Va rugam introduceti varsta.");
            int varsta = Integer.parseInt(scan.nextLine());
            Session session = sessionFactory.openSession();
            session.beginTransaction();
            String hql = "from Employee where age>" + varsta;
            Query query = session.createQuery(hql);
            List<Employee> employeeList = query.list();
            for(Employee emp:employeeList){
                System.out.println(emp);
            }
            session.getTransaction().commit();
            session.close();

        } else {
            System.out.println("6. Afisati un anumit angajat in functie de ID");
            System.out.println("Va rugam introduceti un ID al unui angajat.");
            Session session = sessionFactory.openSession();
            session.beginTransaction();
            int id = Integer.parseInt(scan.nextLine());
            Employee emp = session.get(Employee.class, id);
            if (emp!=null){
                System.out.println(emp);
            } else{
                System.out.println("ID-ul angajatului nu exista.");
            }
            session.getTransaction().commit();
            session.close();

        }
            showMenu();
            optiune = Integer.parseInt(scan.nextLine());
        }
        sessionFactory.close();
    }

    private static void showMenu() {
        System.out.println("1. Introduceti un angajat nou in baza de date.");
        System.out.println("2. Modificati datele unui angajat pe baza ID-ului.");
        System.out.println("3. Stergeti un angajat din baza de date");
        System.out.println("4. Afisati toti angajatii din baza de date");
        System.out.println("5. Afisati un anumit angajat in functie de varsta.");
        System.out.println("6. Afisati un anumit angajat in functie de ID");
        System.out.println("7. Exit Application");
    }
}
